/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package taller;

/**
 *
 * @author l52
 */
public class Basketball {
    
    private String ZapatosM;
    private String UniformeM;
    private int Puntos;
    private String Equipo;
    
    public String getZapatosM() {
        return ZapatosM;
    }
    public void setZapatosM(String ZapatosM) {
        this.ZapatosM = ZapatosM;
    }
    public String getUniformeM() {
        return UniformeM;
    }
    public void setUniformeM(String UniformeM) {
        this.UniformeM = UniformeM;
    }
    public int getPuntos() {
        return Puntos;
    }
    public void setPuntos(int Puntos) {
        this.Puntos = Puntos;
    }
    public String getEquipo() {
        return Equipo;
    }
    public void setEquipo(String Equipo) {
        this.Equipo = Equipo;
    }

    // Método para incrementar los puntos
    public void incrementarPuntos(int puntosExtras) {
        this.Puntos += puntosExtras;
    }
    
    // Método para cambiar el equipo
    public void cambiarEquipo(String nuevoEquipo) {
        this.Equipo = nuevoEquipo;
    }
    
    // Método para cambiar los zapatos
    public void cambiarZapatos(String nuevosZapatos) {
        this.ZapatosM = nuevosZapatos;
    }
    
    public void printInfo() {
        System.out.println("Equipo: " + Equipo);
        System.out.println("Puntos: " + Puntos);
        System.out.println("Uniforme: " + UniformeM);
        System.out.println("Zapatos: " + ZapatosM);    
    }
    
    public static void main(String[] args) {
        Basketball jugador = new Basketball();
        jugador.setEquipo("Lakers");
        jugador.setPuntos(20);
        jugador.setUniformeM("Adidas");
        jugador.setZapatosM("Nike");
        
        jugador.printInfo();
    }
}
