/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller;

/**
 *
 * @author l52
 */
public class TALLER {
    
    private String Jugadas;
    private String ColorUniforme;
    private int NumeroUniforme;
    private String TipoBalón;
    
    public String getJugadas() {
        return Jugadas;
    }
    public void setJugadas(String Jugadas) {
        this.Jugadas = Jugadas;
    }
    public String getColorUniforme() {
        return ColorUniforme;
    }
    public void setColorUniforme(String ColorUniforme) {
        this.ColorUniforme = ColorUniforme;
    }
    public int getNumeroUniforme() {
        return NumeroUniforme;
    }
    public void setNumeroUniforme(int NumeroUniforme) {
        this.NumeroUniforme = NumeroUniforme;
    }
    public String getTipoBalón() {
        return TipoBalón;
    }
    public void setTipoBalón(String TipoBalón) {
        this.TipoBalón = TipoBalón;
    }

    // Método para incrementar los puntos
    public void incrementarNumero(int Numeros) {
        this.NumeroUniforme += Numeros;
    }
    
    // Método para cambiar el equipo
    public void cambiarBalón(String nuevoBalón) {
        this.TipoBalón = nuevoBalón;
    }
    
    // Método para cambiar los zapatos
    public void TipoJugada(String NuevaJugada) {
        this.Jugadas = NuevaJugada;
    }
    
    public void printInfo() {
        System.out.println("TipoBalón: " + TipoBalón);
        System.out.println("NumeroUniforme: " + NumeroUniforme);
        System.out.println("ColorUniforme: " + ColorUniforme);
        System.out.println("Jugadas: " + Jugadas);    
    }
    
    public static void main(String[] args) {
        TALLER jugador = new TALLER();
        jugador.setJugadas("Dribble");
        jugador.setNumeroUniforme(10);
        jugador.setColorUniforme("Negro");
        jugador.setTipoBalón("Masculino");
        
        jugador.printInfo();
    }
}
    